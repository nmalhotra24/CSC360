Nikita Malhotra
Student No: V00790483
CSC 360: Operating Systems
Assignment #2: To stimulate a priority queueing system (PQS)

The purpose of this assignment is to stimulate a priority queueing system (PQS). There are two other documents, along with this one, enclosed in the p2.tar.gz file. 

To run the file named assign2.c, type make on the command line and this will invoke the makefile that will compile the file assign2.c into an executable file PQS. To execute the executable file PQS, type ./PQS test3.txt on the command line.